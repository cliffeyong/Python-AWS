print(" my name is Clifford ")
print (" i love python ")
print ( " x ")
print ( " variable _challenge ")
