easy_math = 1+1
one_third = 100/3
print 
